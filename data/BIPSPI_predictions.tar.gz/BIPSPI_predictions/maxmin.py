scores = []
for code in open('../../list_dimers'):
    code = code.rstrip()
    try:
        for line in open('mixed_2/'+code+'_u1.res'):
            try: score = float(line.split()[3])
            except: continue
            scores.append(score)
    except: continue
    try: 
        for line in open('mixed_2/'+code+'_u2.res'):
            try: score = float(line.split()[3])
            except: continue
            scores.append(score)
    except: continue


print (max(scores), min(scores))
